package com.example.demo;

import java.io.IOException;

import com.example.demo.services.RemoteUserService;
import com.example.demo.utils.ExportBean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		ExportBean bn = new ExportBean();
		System.out.println("...............::" + bn.port);
		SpringApplication.run(DemoApplication.class, args);
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"dubbo/dubbo-provicer.xml"});
        context.start();
        RemoteUserService providerService = (RemoteUserService) context.getBean("remoteUserServiceImpl");
        String result = providerService.sayHello("你好");
        System.out.println("远程调用的结果："+result);
        try {
            System.in.read();
        } catch (IOException e) {

            e.printStackTrace();
        }
        context.close();
	}

}
