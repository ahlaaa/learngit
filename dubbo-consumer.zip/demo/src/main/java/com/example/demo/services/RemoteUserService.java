package com.example.demo.services;

import org.springframework.stereotype.Component;

@Component
public interface RemoteUserService{
    String sayHello(String args);
}