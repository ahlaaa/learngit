package com.example.demo.services.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.example.demo.services.RemoteUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class RemoteUserServiceImpl implements RemoteUserService {

    private static final Logger logger = LoggerFactory.getLogger(RemoteUserServiceImpl.class);

    @Override
    public String sayHello(String name) {
        return "Hello "+name;
    }
}